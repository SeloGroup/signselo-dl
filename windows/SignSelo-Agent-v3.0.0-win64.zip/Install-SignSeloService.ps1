<#
.SYNOPSIS
    SignSelo Next-Gen Windows Service Installer
.DESCRIPTION
    Registers SignSelo Native Agent as a background Windows Service on dedicated Server VMs or Workstations.
    Immune to user logoff, automatically restarts on crash, zero port collisions with legacy NexU / MSDA.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [string]$HubUrl = "wss://hub.signselo.ge/api/connector/stream",

    [Parameter(Mandatory=$false)]
    [string]$NodeToken = "",

    [Parameter(Mandatory=$false)]
    [string]$AutoPin = "",

    [Parameter(Mandatory=$false)]
    [switch]$IsStampCard = $true,

    [Parameter(Mandatory=$false)]
    [string]$InstallDir = "C:\Program Files\SignSelo",

    [Parameter(Mandatory=$false)]
    [switch]$Uninstall = $false
)

$ServiceName = "SignSeloDaemon"
$ServiceDisplayName = "SignSelo Next-Gen Unified Signing Service"

if ($Uninstall) {
    Write-Host "Uninstalling $ServiceName..." -ForegroundColor Yellow
    Stop-Service -Name $ServiceName -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName
    Write-Host "Service $ServiceName removed successfully." -ForegroundColor Green
    return
}

# Ensure administrative privileges
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Warning "Administrator elevation required to register Windows Services. Please run this script as Administrator."
}

# Prepare Install Directory
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

$ExeSource = Join-Path $PSScriptRoot "target\release\signselo-daemon.exe"
if (-not (Test-Path $ExeSource)) {
    $ExeSource = Join-Path $PSScriptRoot "target\debug\signselo-daemon.exe"
}

if (-not (Test-Path $ExeSource)) {
    Write-Error "Could not find compiled signselo-daemon.exe! Run 'cargo build --release' first."
    return
}

$TargetExe = Join-Path $InstallDir "signselo-daemon.exe"
Copy-Item -Path $ExeSource -Destination $TargetExe -Force
Write-Host "Copied binary to: $TargetExe" -ForegroundColor Cyan

# Write Production config.toml
$ConfigPath = Join-Path $InstallDir "config.toml"
$TomlContent = @"
# SignSelo Next-Gen Production Configuration
hub_url = "$HubUrl"
node_token = "$NodeToken"
is_stamp_card = $($IsStampCard.ToString().ToLower())
reconnect_interval_secs = 5
"@

if ($AutoPin) {
    $TomlContent += "`nauto_pin = `"$AutoPin`""
}

Set-Content -Path $ConfigPath -Value $TomlContent -Encoding UTF8
Write-Host "Created configuration file: $ConfigPath" -ForegroundColor Cyan

# Register Windows Service
$existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "Stopping existing $ServiceName..." -ForegroundColor Yellow
    Stop-Service -Name $ServiceName -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName | Out-Null
    Start-Sleep -Seconds 1
}

$BinPath = "`"$TargetExe`" run --config `"$ConfigPath`""
Write-Host "Registering Windows Service: $ServiceName..." -ForegroundColor Cyan

sc.exe create $ServiceName binPath= $BinPath DisplayName= "$ServiceDisplayName" start= auto
sc.exe description $ServiceName "High-performance native smart card signing bridge for SignSelo. Eliminates Java and browser extensions."
sc.exe failure $ServiceName reset= 86400 actions= restart/5000/restart/10000/restart/30000

Write-Host "Starting $ServiceName..." -ForegroundColor Green
Start-Service -Name $ServiceName -ErrorAction SilentlyContinue

Write-Host "============================================================" -ForegroundColor Green
Write-Host "SignSelo Next-Gen Service installed successfully!" -ForegroundColor Green
Write-Host "Status: $( (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue).Status )" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Green
